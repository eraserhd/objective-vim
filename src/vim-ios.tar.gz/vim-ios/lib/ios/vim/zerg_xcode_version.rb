module IOS
  module Vim
    WANTED_ZERG_XCODE_VERSION = '~> 0.5.0'
  end
end
